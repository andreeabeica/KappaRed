(*OPERATOR REDUCTION*)
(*Algorithm 5*)
module FString = struct
		type t=string*string*string*string
		let compare = compare
	   end
module CSet = Set.Make(FString)
module SSet = Set.Make(String)

let counter = ref 1;;

let opSiteConditionSatisfied 
	speciesgen 
	maxopthreshold 
	reactants 
	products 
	modifiers 
	interface 
	rates 
	ratesback 
	observables 
	reverse_observables 
	initconc
		=
		 try
		   let species = 
			if 
			  Hashtbl.mem interface speciesgen 
			then
			  Hashtbl.find interface speciesgen 
			else 
			  speciesgen 
		   in 
	
		   try
		     let sconc = Hashtbl.find initconc species 
		     in
		     (*molecule count of operator sites must be small*)
		     if 
		       sconc > maxopthreshold
	
		     then 
		       None
		     else  
		       (*the operator sites must not be an interesting species or occur as a product in any reaction*)
		       if 
			 (Hashtbl.mem reverse_observables species) 
			  ||
			 (Hashtbl.mem reverse_observables speciesgen) 
			  || 
			 (SSet.cardinal (Genfunc.rtype species products interface) <>0)
		       then 
			 None
		       else 
			 (*each reaction r in which the op.sites are a reactant species is considered in turn*)
			 let (a,b) =
			     SSet.fold 
			      (fun x (s,b) -> 

                              (*LINE 5: reaction must be reversible, have at least 2 reactants and exactly 1 product*)

			         if 

			           (not (Hashtbl.mem ratesback x)) 
				   || 
			           (List.length (Hashtbl.find_all reactants x) <2) 
                                   ||
                                   (List.length (Hashtbl.find_all products x) <>1) 
                                   || 
                                   (b=true)

                                 then 

                                   (CSet.empty, true)  

			         else   

                                   (*sc is the complex species*)
                                                
                                   let sc = Hashtbl.find interface (Hashtbl.find products x) 
                                   in

				   (*LINE 7: the complex species is not an observable, and doesn't*)
					    (*appear as a reactant or product in any other reaction *)

				      if 
				        (Hashtbl.mem reverse_observables sc) 
                                        || 
                                        (SSet.cardinal (Genfunc.rtype sc products interface) <> 1) 
			                || 
                                        (SSet.cardinal (Genfunc.rtype sc reactants interface) <>0)

				      then 

                                        (CSet.empty, true) 

				      else 
				        (*LINE 9: check that every reaction in which the complex 
						  appears as a modifier has no reactants, no other 							           
                                                  modifiers and only one product*)
					let result = SSet.fold 
						      (fun y truth ->
                                                          try
							    let xSp = Hashtbl.find_all products y 
                                                            in
						            if 
                                                               (List.length (Hashtbl.find_all reactants y) <>0)

                                                               || 

							       (*(List.length (Hashtbl.find_all modifiers y) <> 1) || *)

							       (

                                                                 (List.length xSp <>1) 

                                                                 && 

                                                                 (Genfunc.stcoeff (List.hd xSp) y products interface <> List.length xSp)

                                                               ) 

							       || 

                                                               (Hashtbl.mem ratesback y)

						            then 
                                                               true  
								        
                                                            else 
                                                               truth 
							  with _ -> true 
                                                      ) 
					              (Genfunc.rtype sc modifiers interface) 
                                                      false 
			                in
				        if 
                                         result 
				        then
                                         (CSet.empty, true)  
				        else 
                                         let kfkr = String.concat "" ["(";Hashtbl.find rates x;"/";Hashtbl.find ratesback x;")"] 
					 in
					 let aux = SSet.fold 
						   (fun y acc -> 
                                                        begin 
                                                          if 
                                                           (y<> species) 
							  then   
							   let e = string_of_int (Genfunc.stcoeff y x reactants interface) 
                                                           in
                                                           try
							    let sconc = Hashtbl.find reverse_observables (Hashtbl.find interface y) 
							    in
							    if 
                                                             e<>"1" 
                                                            then 
                                                             String.concat "" [acc;"*(";sconc;"^";e;")"]
                                                            else 
                                                             String.concat "" [acc;"*(";sconc;")"]
							   with Not_found -> 
								let name=String.concat "" ["\'opvar";string_of_int !counter;"\'"]
								in
								begin 
                                                                  Hashtbl.add reverse_observables (Hashtbl.find interface y) name;
								  Hashtbl.add observables name (Hashtbl.find interface y);
								  counter := !counter + 1;
								  if 
                                                                   e<>"1" 
								  then 
                                                                   String.concat "" [acc;"*(";name;"^";e;")"]
								  else 
                                                                   String.concat "" [acc;"*(";name;")"]
								end
											
						          else 
                                                           acc; 
                                                        end
                                                   ) 
                                                  (Genfunc.stringsetinterface_of_list interface (Hashtbl.find_all reactants x)) 
						  kfkr
			                 in 
                                         (CSet.add (sc,aux,x,kfkr) s, b) 
						
				    
                              ) 
                              (Genfunc.rtype species reactants interface) 
                              (CSet.empty, false) 
                         
                         in 
		         if 
                           b 
                         then 
                           None 
			 else 
                           Some a;	

	           with Not_found -> None (*no initial concentration found for the species in case*) 
                 with Not_found ->  None  (*species name is incorrect*)
;;
     
   
(*Algorithm 6*)

let opSiteTransform 
    species 
    configs 
    reactants 
    products 
    modifiers 
    interface 
    rates 
    ratesback 
    observables 
    reverse_observables 
    initconc 
      =
	let z= CSet.fold (fun (sc,e,r,kfkr) init -> String.concat "" [init;"+";e]) configs "1" 
	in
	let l= CSet.fold 
               (fun (sc,e,r,kfkr) init -> 
                    let stringset = Genfunc.stringsetinterface_of_list interface (Hashtbl.find_all reactants r) 
                    in
		    SSet.union init stringset
               ) 
               configs 
               SSet.empty
	in
	let result= CSet.fold (fun (sc,e,r1,kfkr) acc-> 
				   
			           (*mRsc returns the set of all reactions r2 in which species sc is a modifier*)

				   let mRsc = Genfunc.rtype sc modifiers interface 
                                   in
				   let _ = SSet.iter
				          (fun r2 -> 
                                                if 
                                                  (List.length (Hashtbl.find_all reactants r2)== 0) 
						  && 
                                                  (not (Hashtbl.mem ratesback r2))
					        then 
						   let _ = List.iter
     							   (fun m -> if m <> species then (Hashtbl.add modifiers r2 m) else ())
							        (Hashtbl.find_all reactants r1)
						   in
	
                                                   (*let newrate = (*if m was a reactant in r1, i don't need to divide by its concentration*)
									
							SSet.fold (fun m init->
								    if 
								     m<> species 
								    then 
								     begin   
								     Hashtbl.add modifiers r2 m;
								     String.concat "" 
                                                                                   [init;
                                                                                    "*(1/";
                                                                                    (Hashtbl.find reverse_observables (Hashtbl.find interface m));
                                                                                    ")"] 
 								     end
								    else 
                                                                     init
                                                                  )
							          l 
								  ""
						   in *)
								
						   Hashtbl.replace 
                                                           rates 
                                                           r2 
                                                           (String.concat "" 
                                                                         ["(";
                                                                           Hashtbl.find rates r2;
                                                                           "*";
                                                                            kfkr;
									   "*";
                                                                           string_of_int (Hashtbl.find initconc species);
                                                                           ")/(";
                                                                            z;
                                                                           ")"](*;newrate]*)
                                                            )
								
					        else  
                                                  ()  
                                          ) 
				          mRsc 
				   in
				   begin 
					Genfunc.removeSpecies sc reactants products modifiers observables interface;
					Genfunc.removeReaction r1 reactants products modifiers rates ratesback;
					SSet.add r1 acc;
				  end 
                              ) 
                              configs 
                              SSet.empty
	in 
	begin
	     Genfunc.removeSpecies species reactants products modifiers observables interface;
	     result
	end 
;;

(*Algorithm 4*)


let opSiteReduction 
    speciesset 
    maxopthreshold 
    reactants 
    products 
    modifiers 
    interface 
    rates 
    ratesback 
    observables 
    reverse_observables 
    initconc 
       = 
	let aux = SSet.fold 
                  (fun x acc -> 
                         let c = opSiteConditionSatisfied 
                                 x  
                                 maxopthreshold 
                                 reactants 
                                 products 
                                 modifiers 
                                 interface 
                                 rates 
                                 ratesback 
                                 observables 
                                 reverse_observables 
                                 initconc 
                         in 
                         match c with
				 | None -> acc
				 | Some a ->
					   let _= opSiteTransform 
                                                  x 
                                                  a 
                                                  reactants 
                                                  products 
                                                  modifiers 
                                                  interface 
                                                  rates 
                                                  ratesback 
                                                  observables 											
                                                  reverse_observables 
                                                  initconc 
					   in

					   SSet.add x acc

                  )  
                  speciesset 
                  (SSet.empty)
	in SSet.diff speciesset aux
;;		
(*!!!remember to take it out of the agents as well*)

