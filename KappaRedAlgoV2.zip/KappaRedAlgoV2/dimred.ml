(*DIMER REDUCTION*)

module SSet = Set.Make(String)

let number = ref 1;;

(*Algorithm 8*)


(*checks that the reaction is of the form a+a <-> 2a*)
let checkform 
    reac 
    reactants 
    products 
    rulerates 
    ruleratesback
      =
        let reacts= Hashtbl.find_all reactants reac 
        in
	let prods= Hashtbl.find_all products reac 
	in
	let prodstring = List.hd prods 
	in
        let length = String.length prodstring 
	in
        let prod1= String.sub prodstring 0 ((length-1)/2) 
	in
        let prod2=String.sub prodstring ((length-1)/2 +1) ((length-1)/2) 
	in
        begin 
	  if 
	   (List.length reacts = 2) 
	   && 
	   (List.hd reacts = List.nth reacts 1) 
	   && 
           (List.length prods = 1) 
	   && 
	   (prod1=prod2) 
	   && 
	   (List.hd reacts = Genfunc.elim prod1 false "") 
	   && 
	   (Hashtbl.mem rulerates reac) 
	   && 
           (Hashtbl.mem ruleratesback reac)
	  then 
	     true
	  else 
	     false 
        end
;;

(*algorithm 8*)
let checkdimreac 
    reac 
    reactants 
    products 
    modifiers 
    rulerates 
    ruleratesback 
    interface 
      = 
        let prods=Hashtbl.find_all products reac 
	in
	let reacts= Hashtbl.find_all reactants reac 
	in
	let mods = Hashtbl.find_all modifiers reac 
	in
        try 
           let a= List.hd reacts 
	   in 
           try
	      let b= List.hd prods 
	      in
   	      let rmod= Genfunc.rtype a modifiers interface 
              in
	      (*line 3*)
	      let rprod = Genfunc.rtype b products interface 
	      in 
	      (*line 1*)
	      if 
		(List.length mods <> 0) 
		|| 
		(List.length prods <>1) 
		|| (List.length reacts <>2)  (*two reactants instead of one, but will check below if they are identical*)
	      then   
		None  
	      (*line 2*)
	      else  
		if  
		   not (checkform reac reactants products rulerates ruleratesback)
		then 
		   None 
		else
		   (*line 4: monomer is never used as a modifier + only reaction that produces the dimer*)
		   if 
		      SSet.cardinal rmod <>0 
		      || 
		      SSet.cardinal rprod <> 1
		   then 
		      None  
		   (*line 5*)
		    else 
                      Some [List.hd reacts; 
			    Hashtbl.find interface (List.hd prods); 
			    Hashtbl.find rulerates reac; 
			    Hashtbl.find ruleratesback reac] 
			
           with Failure "hd" -> None 
	with Failure "hd" -> None  

(*Algorithm 9*)


(*number serves to create new names for st, the species we introduce*)
let modeldimertransform 
    reaction 
    quadr 
    reactants 
    products 
    modifiers 
    initconc 
    rates 
    ratesback 
    agents 
    observables 
    reverse_observables 
    interface
     =



        (*update a kinetic rate on the fly: %mod: [true] do $UPDATE 'rate' 'rate'/10   --- any algebric expression allowed as new value*)
	let  _ = Genfunc.removeReaction reaction reactants products modifiers rates ratesback 
	in
	let sm=Hashtbl.find interface (List.nth quadr 0) 
	in
	let sd = Hashtbl.find interface (List.nth quadr 1) 
	in
	let kplus = List.nth quadr 2 
	in
	let kminus = List.nth quadr 3 
	in
	let csm= if 
		   (Hashtbl.mem initconc sm) 
		 then 
		    Hashtbl.find initconc sm 
		 else 
		    0 
	in
	let csd= if 
		    (Hashtbl.mem initconc sd) 
		 then 
		    Hashtbl.find initconc sd
		 else 
		    0 
	in
	let rRsm = Genfunc.rtype sm reactants interface 
	in
	let pRsm = Genfunc.rtype sm products interface 
	in
	let rRsd = Genfunc.rtype sd reactants interface 
	in
	let mRsd = Genfunc.rtype sd modifiers interface 
	in
	let st= String.concat "" ["dimspecies";string_of_int !number;"()"] 
	in
	let var= String.concat "" ["\'dimvar";string_of_int !number;"\'"] 
	in
	let ke=String.concat "" ["(";kplus;"/";kminus;")"] 
	in
	begin
                number := !number+1;
		(*line 1 - addSpecies (M,st), add a new agent for the new species, with no sites*)
		Hashtbl.add agents st "";

		Hashtbl.add observables var st;

		Hashtbl.add reverse_observables st var;
		Hashtbl.remove initconc sm; Hashtbl.remove initconc sd;
		(*line 2 - [st] = [sm] + 2*[sd]*)
        	Hashtbl.add initconc st  (csm + 2*csd);

		Hashtbl.add interface st st;

		(*lines 3-6 --- replace all monomers that appear as a reactant with the newly introduced species*)
        	SSet.iter (fun x -> 
				let coeff=Genfunc.stcoeff sm x reactants interface 
				in
			    	let stconc=Hashtbl.find reverse_observables st 
				in
			    	let monconc = if 
						Hashtbl.mem reverse_observables sm 
					      then 
						Hashtbl.find reverse_observables sm
					      else 
						"none" 
			    	in
			    	let monconcratio = String.concat "" ["(1/";monconc;")"]
				in
			    	let rate_before=Hashtbl.find rates x 
				in
			   	if 
					Genfunc.contains rate_before monconcratio
			    	then
				
					let new_rate = Str.global_replace 
						      (Str.regexp monconc) 
						      (String.concat "" ["(1/(4*";
									 ke;
									 "))*([sqrt](8*";
									 ke;
									 "*";
									 stconc;
									 "+1) - 1)"]
						      )
						      (  Str.global_replace 
							(Str.regexp monconcratio) 
							(String.concat "" ["(1/";stconc;")"]) 
							rate_before
						      ) 
					in
					begin
						Genfunc.addTable x st coeff reactants;
						Hashtbl.replace rates x new_rate;
					end
				
			        else
					let new_rate = Str.global_replace 
						      (Str.regexp monconc)
					       	      (String.concat "" ["(1/(4*";
									  ke;
									 "))*([sqrt](8*";
									  ke;
								         "*";
									 stconc;
									 "+1) - 1)"]
						      )
					       	      (String.concat "" [rate_before;
									 "*";
									 monconc;
									 "/";
									 stconc]
						      )
					in
					begin
						Genfunc.addTable x st coeff reactants;
						Hashtbl.replace rates x new_rate;
					end
			  ) 
			  rRsm;
        	(* replace all monomers that appear as a product with the newly introduced species, without changing the rates*)
        	SSet.iter (fun x -> 
				let coeff=Genfunc.stcoeff sm x products interface 
				in 
				begin 
					Genfunc.addTable x st coeff products;

				end
			  ) 
			  pRsm; 
		(*lines 7-10*)
		(*replace all dimers that appear as a reactant with the newly introduced species *)
		SSet.iter (fun x -> 
				let coeff = Genfunc.stcoeff sd x reactants interface 
				in
                	        let rate_before = Hashtbl.find rates x 
				in
				let stconc=Hashtbl.find reverse_observables st 
				in
				let dimconc = 
					if 
					  Hashtbl.mem reverse_observables sd
					then 
					  Hashtbl.find reverse_observables sd
					else 
					  "none" 
			    	in
			    	let dimconcratio = String.concat "" ["(1/";dimconc;")"] 
				in
				if 
				  Genfunc.contains rate_before dimconcratio
			   	then
				    let new_rate = Str.global_replace 
						  (Str.regexp dimconc) 
						  (String.concat "" ["(";
								     stconc;
								     "/2-";
								     "(1/(8*";
								     ke;
								     "))*([sqrt](8*";
								     ke;
								     "*";
								     stconc;
								     "+ 1) - 1)";
								     ")"]
						  )
						  (
						    Str.global_replace 
						   (Str.regexp dimconcratio) 
						   (String.concat "" ["(1/";stconc;")"]) 
						   rate_before
						  ) 
				    in
				    begin
					Genfunc.addTable x st coeff reactants;
					Hashtbl.replace rates x new_rate;
				    end
				
			    	else
					let new_rate = Str.global_replace 
						      (Str.regexp dimconc)
					       	      (String.concat "" ["(";
									  stconc;
									 "/2-";
									 "(1/(8*";
									  ke;
									 "))*([sqrt](8*";
									  ke;
									 "*";
									  stconc;
									 "+ 1) - 1)";")"]
						      )
					              (String.concat "" [rate_before;
									 "*";
									 dimconc;
									 "/";
									 stconc]
						      )
					in
					begin
						Genfunc.addTable x st coeff reactants;
						Hashtbl.replace rates x new_rate;
					end
			  ) rRsd;
		(*replace all dimers that appear as a modifier with the newly introduced species*)
		SSet.iter (fun x ->
	                            let coeff = Genfunc.stcoeff sd x reactants interface 
				    in
                	            let rate_before = Hashtbl.find rates x 
				    in
				    let stconc=Hashtbl.find reverse_observables st 
				    in
				    let dimconc = 
					if 
					   Hashtbl.mem reverse_observables sd
					then 
					   Hashtbl.find reverse_observables sd
					else 
					   "none" 
			    	    in
			    	    let dimconcratio = String.concat "" ["(1/";dimconc;")"] 
				    in
				    if 
					Genfunc.contains rate_before dimconcratio
			   	    then
					let new_rate = Str.global_replace 
						      (Str.regexp dimconc) 
						      (String.concat "" ["(";
									  stconc;
									 "/2-";
									 "(1/(8*";
									   ke;
									 "))*([sqrt](8*";
									   ke;
									  "*";
									   stconc;
									  "+ 1) - 1)";
									  ")"]
						      )
						      (
							Str.global_replace 
						       (Str.regexp dimconcratio) 
						       (String.concat "" ["(1/";stconc;")"]) 
							rate_before
						      ) 
					in
					begin
						Genfunc.addTable x st 1 modifiers;
						Hashtbl.replace rates x new_rate;
					end
				
			    	    else
					let new_rate = Str.global_replace 
						      (Str.regexp dimconc)
					              (String.concat "" ["(";
									 stconc;
									 "/2-";
									 "(1/(8*";
									  ke;
									 "))*([sqrt](8*";
									  ke;
									 "*";
									  stconc;
									 "+ 1) - 1)";
									 ")"]
						      )
					              (String.concat "" [rate_before;"*";dimconc;"/";stconc])
					in
					begin
						Genfunc.addTable x st 1 modifiers;
						Hashtbl.replace rates x new_rate;
					end
			  ) 
                          mRsd;
		(*lines 12-14*)
		Genfunc.removeSpecies sm reactants products modifiers observables interface;
		Genfunc.removeSpecies sd reactants products modifiers observables interface;
	
	end
;;

(*Algorithm 7*)

let dimerReduction 
    reactants 
    products 
    modifiers 
    initconc 
    rates 
    ratesback 
    agents 
    observables 
    reverse_observables 
    interface 
    reactionset 
    speciesset
       =
	
	let aux=SSet.fold ( fun x acc -> 
				let c= checkdimreac 
					x 
					reactants 
					products 
					modifiers 
					rates 
					ratesback 
					interface 
				in match c with
					| None -> acc 
					| Some a -> 
							let sp = Hashtbl.find reactants x
							in 
							let _ = modeldimertransform 
								x 
								a 
								reactants 
								products 
								modifiers 
								initconc 
								rates 
								ratesback 						
								agents 
								observables 
								reverse_observables 
								interface

							in
							SSet.add sp acc
								
			  )
	 		  reactionset 
			  (SSet.empty)
	in
	SSet.diff  speciesset aux
;;
