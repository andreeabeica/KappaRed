(*MICHAELIS MENTEN*)
open Printf

module SSet = Set.Make(String)

module SString = struct
	type t=string*string*string*string*string*string
		let compare = compare
	   end

module SixSet = Set.Make(SString)

let counter = ref 1;;

(*auxiliary functions*)
(*addReactant (M,st,r',E(sm,r)), addModifier(M,st,r',E(sm,r))*)

let rec addTable 
	reaction 
	species 
	coeff 
	table 
	  =
	match coeff with
		| 0 -> ()
		| coeff -> Hashtbl.add table reaction species; 
			   addTable reaction species (coeff-1) table 
;;

(*removeSpecies function - removes species from table given as argument*)

let remove 
    species
    table 
    interface 
	= 
  	let aux = Hashtbl.fold (fun key value init -> 
					try 
						let value_interface = Hashtbl.find interface value 
						in      
						if 
						   value_interface <> species 
						then 
						   (key,value) :: init 
						else 
						    init 
					with Not_found -> (key,value) :: init
				) 
				table 
				[] 
	in
   	begin
   		Hashtbl.clear table;
   		List.iter (fun (x,y) -> Hashtbl.add table x y) aux;
 	end
;;

let removeSpecies 
    species 
    reactants 
    products 
    modifiers 
    observables 
    interface
	=
	begin
		remove species reactants interface;
		remove species products interface;
		remove species modifiers interface;
		remove species observables interface;
	end
;;

(*removes reaction from table*)
let removeReactionaux 
    reaction 
    table 
	=
    	while 
	    Hashtbl.mem table reaction 
	do 
	    Hashtbl.remove table reaction 
	done
;;

let removeReaction 
    reaction 
    reactants 
    products 
    modifiers 
    rates 
    ratesback
	=
	begin
		removeReactionaux  reaction reactants;
		removeReactionaux  reaction products;
		removeReactionaux  reaction modifiers;
		removeReactionaux  reaction rates;
		removeReactionaux  reaction ratesback;
	end
;;

(*returns the stoichiometry of species in reaction reac, as a reactant/modifier/product, as specified by the table given in argument*)
(*used for computing E(sm,r)*)

let stcoeff 
    species 
    reac 
    table 
    interface 
	=
	let all_components = Hashtbl.find_all table reac 
	in
	List.fold_left (fun acc x -> 
				if 
				   (Hashtbl.find interface x)= (Hashtbl.find interface species) 
				then 
				    acc+1 
				else 
				    acc
			) 
			0 
			all_components
;;



(*returns the set of reactions in which species sp appears as either modifier/product/reactant, depending on the table passed as argument*)
let rtype 
    sp 
    table 
    interface=
    Hashtbl.fold (fun key value init -> 
			try 
				let value_interface = Hashtbl.find interface value 
				in  
				if 
				   value_interface =sp 
				then 
				   SSet.add key init 
				else 
				   init 
			with Not_found -> init
		) 
		table 
		(SSet.empty)
;;


(*algorithm 2*)

let rapidEqConditionSatisfied 
    speciesgen 
    ratethreshold 
    reactants 
    products 
    modifiers 
    interface 
    rates 
    ratesback 
    observables 
    reverse_observables 
    initconc 
    variables
	=
	try 
	let species = Hashtbl.find interface speciesgen 
	in
	(*species must not be an observable and it must be a reactant in at least one reaction*)
	if 
	   (Hashtbl.mem reverse_observables species) 
	   || 
           (Hashtbl.mem reverse_observables speciesgen) 
           || 
           (SSet.cardinal (rtype species reactants interface)==0)
	then 
	   None
	else   (* loop through each reaction in which species is a reactant*)
           let (c,boolean) = SSet.fold
				(fun x (s,b) ->  (*let _ = printf "Looking for a reversible reaction\n" in*)
					if 
					   b=true 
					then 
					   (SixSet.empty,true) 
					else
					    if 
					      (not (Hashtbl.mem ratesback x)) 
					      || 
					      (List.length (Hashtbl.find_all reactants x) <> 2)
					      || 
					      (List.length (Hashtbl.find_all products x) <> 1)
					      || 
					      (List.length (Hashtbl.find_all modifiers x) <>0) 
							   
					    then 
					      (SixSet.empty, true) 
					    else (*sc should always be found, every reaction has a product*)
					      let sc = Hashtbl.find interface (Hashtbl.find products x)
					      in
					      if 
						(Hashtbl.mem initconc sc) 
						|| 
						(Hashtbl.mem reverse_observables sc)
					      then
						(SixSet.empty, true) 
					      else
						if 
						   (SSet.cardinal (rtype sc reactants interface) <>1) 
						   || 
						   (SSet.cardinal (rtype sc modifiers interface) <>0) 
						   || 
						   (SSet.cardinal (rtype sc products interface) <>1)
                        then
						    (SixSet.empty, true) 
						else

						    let r2=SSet.choose (rtype sc reactants interface)
						    in
						    if 
							(Hashtbl.mem ratesback r2) 
							|| 
							(List.length (Hashtbl.find_all reactants r2) <>1)  
							|| 
							(List.length (Hashtbl.find_all modifiers r2) <>0)
						    then 
							(SixSet.empty, true) 
						    else
							if 
							   (not (List.mem species (Hashtbl.find_all products r2) 	
							   || 
							   List.mem speciesgen (Hashtbl.find_all products r2))) 
						           || 
							   (List.length (Hashtbl.find_all products r2) <1
							   || 
							   List.length (Hashtbl.find_all products r2) >2)
					 		then 
							   (SixSet.empty, true) 
							else
							    try 
								let a= (Hashtbl.find variables (Hashtbl.find rates r2)) 
								in
								let d = (Hashtbl.find variables (Hashtbl.find ratesback x)) 
								in
								if 
								   a/.d > ratethreshold
								then
                                  (SixSet.empty, true)
								else
							 	   let s1= List.find 
									   (fun a -> a<>species && a<>speciesgen) 
									   (Hashtbl.find_all reactants x)
								   in
								           
								   if 
									Hashtbl.mem reverse_observables (Hashtbl.find interface s1) 
								   then  
									(SixSet.add (s1,
                                         					     sc,
                                                                                     String.concat "" ["(";
													Hashtbl.find rates x;
													"/";
													Hashtbl.find ratesback x;
													")"],
									             Hashtbl.find rates r2,
										     x,
									             r2
										     )  
										     s, 
									b
									)
								   else 
									let name=String.concat "" ["\'mmvar";string_of_int !counter;"\'"]
									in
									begin 
                                       Hashtbl.add reverse_observables (Hashtbl.find interface s1) name;
									   Hashtbl.add observables name (Hashtbl.find interface s1);
									   counter := !counter + 1;
									   (SixSet.add (s1,
                                         						sc,
                                                                                        String.concat "" ["(";
													  Hashtbl.find rates x;
													  "/";
													  Hashtbl.find ratesback x;
													  ")"],
											Hashtbl.find rates r2,
											x,
											r2
											)  
											s,
									   b
									   )
											
									end 
			                                    with Not_found-> let _ = printf "Rates not found?\n" in (SixSet.empty,true)
										
				)
				(rtype species reactants interface) 
                (SixSet.empty, false)
	   in
	   if 
	      	boolean 
	   then  
	      	None 
	   else 
		Some c;
		
	with Not_found -> None (*species name or interface is incorrect*)
;;

(*algorithm 3*)

let rapidEqTransform 
    species 
    configs 
    reactants 
    products 
    modifiers 
    interface 
    rates 
    ratesback 
    observables 
    reverse_observables 
    initconc
	 =
	
	let z = SixSet.fold (fun (s1,sc,k1,k2,r1,r2) init-> 
				String.concat "" [init;
						  "+(";
						  k1;
						  "*";
						  Hashtbl.find reverse_observables (Hashtbl.find interface s1);
						  ")"]
			    ) 			
			    configs 
			    "1" 
	in 
    begin
        SixSet.iter (fun (s1,sc,k1,k2,r1,r2) ->
            let e = stcoeff s1 r1 reactants interface
            in
            try
                begin
                    addTable r2 s1 e reactants;
                    Hashtbl.replace rates r2 (String.concat "" ["((";
											   k2;
											   "*";
											   string_of_int (Hashtbl.find initconc species);
											   "*";
											   k1;
											   ")/(";
											   z;
											   "))"]);


                    removeSpecies sc reactants products modifiers observables interface;
                    removeReaction r1 reactants products modifiers rates ratesback;
                end
            with _ -> ()(*printf "Wut!? in rapideqtransform\n"*)
        )
        configs;
        removeSpecies species reactants products modifiers observables interface;
    end
;;
	

(*algorithm 1*)
let rapidEqApprox 
    speciesset 
    ratethreshold 
    reactants 
    products 
    modifiers 
    interface  
    rates 
    ratesback 
    observables 
    reverse_observables 
    initconc 
    variables
	 =
	let aux = SSet.fold (fun x acc ->
				let
                    c= rapidEqConditionSatisfied
					x 
					ratethreshold 
					reactants 
					products 
					modifiers 
					interface 
					rates 
					ratesback 
					observables 							
					reverse_observables 
					initconc 
					variables
                                in match c with
					| None ->  acc 
					| Some a -> begin 
							rapidEqTransform 
							x 
							a 
							reactants 
							products 
							modifiers 		
							interface 
							rates 
							ratesback 
							observables 
							reverse_observables 
							initconc; 

							SSet.add x acc 
						    end
			    ) 
		            speciesset  
                            (SSet.empty)
	in 
        SSet.diff speciesset aux
;;

