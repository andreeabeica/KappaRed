(*AUXILIARY FUNCTIONS*)

module SSet = Set.Make(String)

(*removeSpecies function - removes species from table given as argument*)

let remove species table interface = 
   let aux = 
	Hashtbl.fold (fun key value init -> 
					try 
						let value_interface = Hashtbl.find interface value 
						in      
							if value_interface <> species 
							then (key,value) :: init 
							else init 
					with Not_found -> (key,value) :: init) table [] 
   in
   begin
   	Hashtbl.clear table;
   	List.iter (fun (x,y) -> Hashtbl.add table x y) aux;
   end
;;


let removeSpecies species reactants products modifiers observables interface=
	begin
		remove species reactants interface;
		remove species products interface;
		remove species modifiers interface;
		remove species observables interface;
	end
;;

(*removes reaction from table*)
let removeReactionaux reaction table =
    while 
	Hashtbl.mem table reaction
    do 
	Hashtbl.remove table reaction 
    done
;;

let removeReaction reaction reactants products modifiers rates ratesback =
	begin
		removeReactionaux  reaction reactants;
		removeReactionaux  reaction products;
		removeReactionaux  reaction modifiers;
		removeReactionaux  reaction rates;
		removeReactionaux  reaction ratesback;
	end
;;

(*returns the stoichiometry of species in reaction reac, as a reactant/modifier/product, 
  as specified by the table given in argument ----> used for computing E(sm,r)*)

let stcoeff species reac table interface =
	let all_components = Hashtbl.find_all table reac 
	in
	List.fold_left (fun acc x -> 
				if (Hashtbl.find interface x)= (Hashtbl.find interface species) 
				then 
					acc+1 
				else 
					acc
			) 0 all_components
;;



(*returns the set of reactions in which species sp appears as either modifier/product/reactant, 
  depending on the table passed as argument*)

let rtype sp table interface=
    Hashtbl.fold (fun key value init -> try 
						let value_interface = Hashtbl.find interface value
						in  
							if value_interface =sp 
							then SSet.add key init 
							else init 
					with Not_found -> init
		 ) table (SSet.empty)
;;


let stringset_of_list li =
	List.fold_left (fun s elem -> SSet.add elem s) SSet.empty li
;;

let stringsetinterface_of_list interface li =
	List.fold_left (fun s elem -> SSet.add (Hashtbl.find interface elem) s) SSet.empty li
;;

(*addReactant (M,st,r',E(sm,r)), addModifier(M,st,r',E(sm,r))*)

let rec addTable reaction species coeff table =
	match coeff with
		| 0 -> ()
		| coeff -> Hashtbl.add table reaction species; addTable reaction species (coeff-1) table 

;;

(*used in eliminating link patterns from a species name string*)

let rec elim old check newstring =
	try
		let ln = String.length old 
		in
		let aux = String.sub old 1 (ln-1) 
		in
		match old.[0] with
			| '!' -> elim  aux true newstring
			| ',' -> elim aux false (String.concat "" [newstring;","])
			| ')' -> elim aux false (String.concat "" [newstring;")"])
			| _ as c-> match check with 
					| true -> elim aux true newstring
			    		| false -> elim aux false (String.concat "" [newstring;(String.make 1 c)])
	with _ -> newstring
;;

(*checks if s2 is a substring of s1*)
let contains s1 s2 =
    let re = Str.regexp_string s2
    in
        try ignore (Str.search_forward re s1 0); true
        with Not_found -> false
;;

(*add dimers to agent list*)

let rec plusdimer agents number =
	match number with
	| 0 -> agents
	| _ ->  plusdimer (SSet.add (String.concat "" ["dimspecies";string_of_int number;"()"]) agents) (number-1)
;;
