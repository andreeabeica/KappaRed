open Printf
open Str
module SLink= Set.Make(String)
module FString = struct
		type t=string*string*string*string
		let compare = compare
	   end
module CSet = Set.Make(FString)
module SSet = Set.Make(String)
module SString = struct
	type t=string*string*string*string*string*string
		let compare = compare
	   end
module SixSet = Set.Make(SString)



(*let counter = ref 1;;
let number = ref 1;;*)





(*main algorithm*)

      let _ =
	  let cin =
		if 
			Array.length Sys.argv > 1
		then 
			open_in Sys.argv.(1)
		else 
			stdin 
          in 
	  let buffer=Buffer.create 1 
          in 
	  let links= SLink.empty 
	  in 
	  let bufferaux=Buffer.create 1 
	  in
          let lexbuf = Lexing.from_channel cin 
	  in
          let result = List.filter (fun x -> x <>"as") (Parser.main (Lexer.token buffer bufferaux links) lexbuf) 
	  in
          let sset = Hashtbl.fold (fun key _ l -> 
					let 
					   aux = String.concat "" [key;
								   "(";
								   (String.concat "," (List.rev (Hashtbl.find_all (Lexer.agent_hashtable) key)));
								   ")"]
					in 
					if 
						List.mem aux l 
					then 
						l 
					else 
						aux :: l
				  ) 
				  (Lexer.agent_hashtable) 
				  [] 
	  in 
          let speciesset = Genfunc.stringset_of_list sset 
	  in 
          let _ = List.iter (fun x ->  
				if 
					(not (Hashtbl.mem Lexer.rule_reactants x)) 
					&& 
					(not (Hashtbl.mem Lexer.rule_modifiers x))
				then 
					Hashtbl.add Lexer.rule_reactants x ""
				else 
					()
			    ) 
			    result 
	  in
	  let _ = List.iter (fun x -> 
				if 
					(not (Hashtbl.mem Lexer.rule_products x)) 
					&& 
					(not (Hashtbl.mem Lexer.rule_modifiers x))
				then 
					Hashtbl.add Lexer.rule_products x ""
				else 
					()
			    ) 
			    result 
	  in
	  let rslt = Mmred.rapidEqApprox 
			   speciesset 
			   10. 
 			   Lexer.rule_reactants 
			   Lexer.rule_products 
			   Lexer.rule_modifiers 
			   Lexer.interface 
			   Lexer.rule_rates 
			   Lexer.rule_rates_back 
			   Lexer.observables 
			   Lexer.reverse_observables 
			   Lexer.initconc 
			   Lexer.variables
	  in
	  let rslt2 = Opred.opSiteReduction 
			    rslt 
			    10   
			    Lexer.rule_reactants 
			    Lexer.rule_products 
			    Lexer.rule_modifiers 
			    Lexer.interface 
			    Lexer.rule_rates 
			    Lexer.rule_rates_back 
			    Lexer.observables 
			    Lexer.reverse_observables 
			    Lexer.initconc 
	  in
	  let rslt3 =  Dimred.dimerReduction  
			      Lexer.rule_reactants 
			      Lexer.rule_products 
			      Lexer.rule_modifiers 
			      Lexer.initconc 
			      Lexer.rule_rates 
			      Lexer.rule_rates_back
			      Lexer.agent_hashtable
			      Lexer.observables
			      Lexer.reverse_observables
			      Lexer.interface
			     (Hashtbl.fold (fun key value acc -> SSet.add key acc) (Lexer.rule_rates) (SSet.empty))
			      rslt2 
	  in 
	  let finalreactions = Hashtbl.fold (fun key value init -> SSet.add key init) (Lexer.rule_rates) (SSet.empty)
	  in	
	  let file= open_out ("output/output.ka") 
	  in
	  let final = Genfunc.plusdimer rslt3 (!Dimred.number-1)
	  in	
	  begin     
		(*printf "Non- Enzymes, non-operators, non-dimers:\n";
		SSet.iter (fun x-> printf "%s\n" x) rslt3;*)
		SSet.iter (fun x -> Printf.fprintf file "%%agent: %s\n" x) final; 
		Printf.fprintf file "\n\n";
		SSet.iter 
			(fun x -> 
				let reactants = Hashtbl.find_all  (Lexer.rule_reactants)  x
				in
				let modifiers = Hashtbl.find_all  (Lexer.rule_modifiers) x
				in
				let products = Hashtbl.find_all  (Lexer.rule_products) x
				in
				let rate = Hashtbl.find (Lexer.rule_rates) x
				in
				let revrate = if 
						   (Hashtbl.mem (Lexer.rule_rates_back) x) 
					      then 
						   (Hashtbl.find (Lexer.rule_rates_back) x) 
					      else 
						   "" 
				in
				let rhs = String.concat "," (List.append reactants modifiers)
				in
				let lhs = String.concat "," (List.append products modifiers)
				in
				begin
					Printf.fprintf file "%s   " x;
					Printf.fprintf file "%s" rhs;
					if 
					    (revrate="") 
					then 
					     Printf.fprintf file "  ->  " 
					else 
					     Printf.fprintf file "<->";
					Printf.fprintf file "%s" lhs;
					Printf.fprintf file " @ ";
					Printf.fprintf file "%s " rate;
					if 
					    (revrate="") 
					then 
					     Printf.fprintf file "\n\n\n\n" 
					else 
					     Printf.fprintf file ",%s \n\n\n\n" revrate;
				end
					  
			) 
			finalreactions;  

		Hashtbl.iter (fun key value -> if SSet.mem value final then Printf.fprintf file "%%obs: %s %s \n" key value else ()) Lexer.observables;
		Printf.fprintf file "\n\n";
		Hashtbl.iter (Printf.fprintf file "%%var: %s  %f \n") Lexer.variables;
		Printf.fprintf file "\n\n";
		SSet.iter (fun x -> 
				if 
				   Hashtbl.mem (Lexer.initconc) x 
				then 
				   Printf.fprintf file "%%init: %d %s\n" (Hashtbl.find Lexer.initconc x) x 
				else 
				   ()
			  ) final;
		(*Hashtbl.iter (fun key value -> Printf.fprintf file "%%init:  %d  %s \n" value key) (Lexer.initconc);*)
		

          end
